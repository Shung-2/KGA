#pragma once
#define PI 3.14159f
#define PI2 PI * 2

namespace SUNFL_UTIL
{
	float getDistance(float x1, float y1, float x2, float y2);

	float getAngle(float x1, float y1, float x2, float y2);
}